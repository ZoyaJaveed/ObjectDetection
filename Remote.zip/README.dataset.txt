# remotes > 2023-03-23 10:55pm
https://universe.roboflow.com/efe-efesefe-gvfaz/remotes

Provided by a Roboflow user
License: CC BY 4.0

